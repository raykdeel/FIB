var searchData=
[
  ['nota_5fmaxima',['nota_maxima',['../class_estudiant.html#a5df5eed414c87a2a1c2efa4194633afd',1,'Estudiant']]]
];
