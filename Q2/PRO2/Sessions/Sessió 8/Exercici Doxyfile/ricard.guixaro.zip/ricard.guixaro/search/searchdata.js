var indexSectionsWithContent =
{
  0: "acelmnpt~",
  1: "ce",
  2: "cep",
  3: "acelmnt~",
  4: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Pàgines"
};

