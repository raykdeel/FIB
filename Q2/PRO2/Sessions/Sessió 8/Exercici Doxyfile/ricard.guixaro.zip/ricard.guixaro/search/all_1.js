var searchData=
[
  ['cjt_5festudiants',['Cjt_estudiants',['../class_cjt__estudiants.html',1,'Cjt_estudiants'],['../class_cjt__estudiants.html#a31ffe72cadcf58d82c8b9f6659c56e7a',1,'Cjt_estudiants::Cjt_estudiants()']]],
  ['cjt_5festudiants_2ehh',['Cjt_estudiants.hh',['../_cjt__estudiants_8hh.html',1,'']]],
  ['comp',['comp',['../class_estudiant.html#a5f19b7f7436e8c12a13159335040ae42',1,'Estudiant']]],
  ['consultar_5fdni',['consultar_DNI',['../class_estudiant.html#ad37108e53c6c0f1fcb5786e77e1902f5',1,'Estudiant']]],
  ['consultar_5fnota',['consultar_nota',['../class_estudiant.html#a21afbb59cddf87258d600df04ab95397',1,'Estudiant']]]
];
