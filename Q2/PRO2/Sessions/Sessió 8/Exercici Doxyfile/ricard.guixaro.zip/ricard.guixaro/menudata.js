var menudata={children:[
{text:"Pàgina principal",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Llista de Classes",url:"annotated.html"},
{text:"Membres de Classes",url:"functions.html",children:[
{text:"Tot",url:"functions.html"},
{text:"Funcions",url:"functions_func.html"}]}]},
{text:"Fitxers",url:"files.html",children:[
{text:"Llista dels Fitxers",url:"files.html"},
{text:"Membres de Fitxers",url:"globals.html",children:[
{text:"Tot",url:"globals.html"},
{text:"Funcions",url:"globals_func.html"}]}]}]}
