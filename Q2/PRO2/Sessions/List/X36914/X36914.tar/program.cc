// (c) FIBerHub, https://fiberhub.tk

#include <iostream>
#include <list>
#include "Estudiant.hh"
#include "LlistaIOEstudiant.hh"
using namespace std;

int main() {
    list<Estudiant> l;
    LlegirLlistaEstudiant(l);

    int x;
    cin >> x;

    int c = 0;
    for (list<Estudiant>::iterator it = l.begin(); it != l.end(); ++it) {
        if ((*it).consultar_DNI() == x) ++c;
    }

    cout << x << ' ' << c << endl;
}
