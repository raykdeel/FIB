#include <iostream>
#include "Cjt_Clusters.hh"
#include <vector>
#include <string>
using namespace std;

Cjt_Clusters::Cjt_Clusters() {
}

void Cjt_Clusters::add_cluster(const Cluster& A) {
    string s = A.query_tree().value();
    // mclu_iterator it = mclu.find(s); //?
    mclu.insert(make_pair(s, A));
    bool indicador = true;
    clusters_distance_update(indicador, s);
}   

void Cjt_Clusters::erase_cluster(Cluster A) {
    string s = A.query_tree().value();
    mclu.erase(s);
    table.erase(s);
    bool indicador = false;
    clusters_distance_update(indicador, s);
}

bool Cjt_Clusters::cluster_exist(string id) {
    mclu_iterator it = mclu.find(id);
    if (it != mclu.end()) {
        return true;
    }
    else return false;
}

void Cjt_Clusters::initialize_clusters(const Cjt_Especies A) {
    if (mclu.size() != 0) {
        mclu.erase(mclu.begin(), mclu.end());
        table.erase(table.begin(), table.end());
        distancies.erase(distancies.begin(),distancies.end());
    }
    map<string, Especie> aux = A.query_mesp();
    if (aux.size() >= 1) {
        for (map<string, Especie>::iterator it1 = aux.begin(); it1 != aux.end(); ++it1) {
            Especie c = it1->second;
            string s = it1->first;
            BinTree<string> b(s);
            Cluster a(b);
            mclu.insert(make_pair(s, a));
        }
        table = A.query_tablee();
    }
}

void Cjt_Clusters::wpgma_algorithm() {
    pair<string, string> u = dmin();
    mclu_iterator it1 = mclu.find(u.first);
    mclu_iterator it2 = mclu.find(u.second);
    if (it1 != mclu.end() and it2 != mclu.end()) {
        Cluster A = it1->second;
        Cluster B = it2->second;
        string s = u.first + u.second;
        Cluster C;
        C.clusters_fusion(A, B, s);
        add_cluster(C);
        erase_cluster(A);
        erase_cluster(B);
    }
}

double Cjt_Clusters::cluster_distance(Cluster A, Cluster B) {
    if (A.cluster_size() == 1 and B.cluster_size() == 1) {
        double d = 0;
        string id1 = A.query_tree().value();
        string id2 = B.query_tree().value();
        table_column_iterator it3;
        table_row_iterator it2;
        if (id2 < id1) {
            it3 = table.find(id2);
            if (it3 != table.end()) {
                it2 = it3->second.find(id1);
                if (it2 != it3->second.end()) {
                    d = it2->second;
                }
            }
        } else {
            it3 = table.find(id1);
            if (it3 != table.end()) {
                it2 = it3->second.find(id2);
                if (it2 != it3->second.end()) {
                    d = it2->second;
                }
            }
        }
        return d;
    } else {
        double d1 = 0, d2 = 0; //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        string id1 = A.query_tree().value();
        string id2 = B.query_tree().left().value();
        string id3 = B.query_tree().right().value();
        table_column_iterator it3 = table.begin();
        table_row_iterator it2 = it3->second.begin();
        if (id2 < id1) {
            it3 = table.find(id2);
            if (it3 != table.end()) {
                it2 = it3->second.find(id1);
                if (it2 != it3->second.end()) {
                    d1 = it2->second;
                }
            }
        } else {
            it3 = table.find(id1);
            if (it3 != table.end()) {
                it2 = it3->second.find(id2);
                if (it2 != it3->second.end()) {
                    d1 = it2->second;
                }
            }
        }
        if (id3 < id1) {
            it3 = table.find(id3);
            if (it3 != table.end()) {
                it2 = it3->second.find(id1);
                if (it2 != it3->second.end()) {
                    d2 = it2->second;
                }
            }
        } else {
            it3 = table.find(id1);
            if (it3 != table.end()) {
                it2 = it3->second.find(id3);
                if (it2 != it3->second.end()) {
                    d2 = it2->second;
                }
            }
        }   
        return (d1+d2) / 2;
    }
}

void Cjt_Clusters::clusters_distance_update(bool indicador, string id) {
    if (indicador) {
        mclu_iterator it = mclu.find(id);
        double dist;
        map<string, double> aux;
        table.insert(make_pair(id, aux));
        for(map<string, map<string, double>>::iterator it3 = table.begin(); it3 != table.end(); ++it3) {
            table_row_iterator it4 = it3->second.begin();
            mclu_iterator it1 = mclu.find(it3->first);
            if (it1 != mclu.end()) {
                string s = it3->first;
                string s1 = it->second.query_tree().left().value(); 
                string s2 = it->second.query_tree().right().value();
                if (s < id) {
                    if(s1 != s and s2 != s) {
                        dist = cluster_distance(it1->second, it->second);
                        it3->second.insert(make_pair(id, dist));
                    }
                }    
                s = it1->first;        
                if (s > id) {
                    if (s1 != s and s2 != s) {
                        dist = cluster_distance(it1->second, it->second);
                        map<string, map<string, double>>::iterator it5 = table.find(id);  
                        if (it5 != table.end()) {
                            it5->second.insert(make_pair(it1->first, dist));
                        }                     
                    }
                }
            }
        }
    } else {
        map<string, map<string, double>>::iterator it3 = table.begin();
        mclu_iterator it1 = mclu.begin();
        mclu_iterator it = mclu.find(id);
        while (it1 != it) {
            it3->second.erase(id);
            ++it1;
            ++it3;
        }
    }
}

pair<string, string> Cjt_Clusters::dmin(){
    pair<string, string> minimal_dist;
    double d = 0;
    bool firsttime = true;
    for (table_column_iterator it1 = table.begin(); it1 != table.end(); ++it1) {
        if (not it1->second.empty()) {
            for (table_row_iterator it2 = it1->second.begin(); it2 != it1->second.end(); ++it2) {
                if (firsttime) {
                    minimal_dist.first = it1->first;
                    minimal_dist.second = it2->first;
                    d = it2->second;
                    firsttime = false;
                }
                else {
                    if (it2->second <= d) {
                        if (it2->second == d) {
                            if (it1->first < minimal_dist.first) {
                                minimal_dist.first = it1->first;
                                minimal_dist.second = it2->first;
                                d = it2->second;
                            }
                        } else {
                            minimal_dist.first = it1->first;
                            minimal_dist.second = it2->first;
                            d = it2->second;
                        }
                    }              
                }
            }
        }
    }
    distancies.insert(make_pair(minimal_dist.first+minimal_dist.second, d/2));
    // distancies.insert(make_pair(minimal_dist.first, 0));
    // distancies.insert(make_pair(minimal_dist.second, 0));
    return minimal_dist;
}

int Cjt_Clusters::clusters_set_size() const{
    return mclu.size();
}

Cluster Cjt_Clusters::query_final_cluster() {
    mclu_iterator it = mclu.begin();
    return it->second;
}

void Cjt_Clusters::print_table_clusters() {
    if (mclu.size() != 0) { //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        int i = 0;
        for (table_column_iterator it1 = table.begin(); it1 != table.end(); ++it1) {
            cout << it1->first << ":";
            if (i < table.size()-1) cout << " ";
            table_row_iterator it2 = it1->second.begin();
            int j = 0;
            while (it2 != it1->second.end()) {
                cout << it2->first << " (" << it2->second << ")";
                if (j < it1->second.size() - 1) cout << " ";
                ++it2;
                ++j;
            }
            ++i;
            cout << endl;
        }
    }
}

Cluster Cjt_Clusters::find_cluster(string id) {
    mclu_iterator it = mclu.find(id);
    return it->second;
}

void Cjt_Clusters::print_cluster(Cluster a){
    cout << "[";
    string s = a.query_tree().value();
    if (a.cluster_size() > 1) {
        table_row_iterator it2 = distancies.find(s);
        if (it2 != distancies.end()) {
            cout << "(" << s << ", ";
            cout << it2->second << ") ";
            print_cluster(a.query_tree().left());
            print_cluster(a.query_tree().right());
            cout << "]";
        }
    } else cout << s << "]";;
}

