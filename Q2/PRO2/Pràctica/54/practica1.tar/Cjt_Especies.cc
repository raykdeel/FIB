#include "Cjt_Especies.hh"
using namespace std;

Cjt_Especies::Cjt_Especies() {
}

void Cjt_Especies::add_species(const Especie& a) {
    string id = a.query_identifier();
    mesp.insert(make_pair(id, a));
    bool indicador = true;
    species_distance_update(indicador, id);    
}

void Cjt_Especies::erase_species(string id) {
    map<string,Especie>::iterator it = mesp.find(id);
    bool indicador = false;
    species_distance_update(indicador, id);
    mesp.erase(id);
    tablee.erase(id);
}

void Cjt_Especies::initialize_distances() {
    for(map<string,Especie>::iterator it1 = mesp.begin(); it1 != mesp.end(); ++it1) {
        rowe aux;
        double dist;
        for(map<string,Especie>::iterator it2 = it1; it2 != mesp.end(); ++it2) {
            if (it1 != it2) {
                dist = species_distance(it1->first, it2->first);
                aux.insert(make_pair(it2->first, dist));
            }
            
        }
        string s = it1->first;
        tablee.insert(make_pair(s, aux));
        //it1->second.modify_distances(aux);
    }
}

void Cjt_Especies::species_distance_update(bool indicador, string id) {
    if (indicador) {
        map<string,Especie>::iterator it = mesp.find(id);
        double dist;
        map<string, double> aux;
        tablee.insert(make_pair(id, aux));
        for(map<string, map<string, double>>::iterator it3 = tablee.begin(); it3 != tablee.end(); ++it3) {
            tablee_rowe_iterator it4 = it3->second.begin();
            map<string, Especie>::iterator it1 = mesp.find(it3->first);
            if (it1 != mesp.end()) {
                string s = it3->first;
                if (s < id) {
                    dist = species_distance(id, s);
                    it3->second.insert(make_pair(id, dist));
                }
                if (s > id) {
                    dist = species_distance(s, it->first);
                    map<string, map<string, double>>::iterator it5 = tablee.find(id);
                    if (it5 != tablee.end()) {
                        it5->second.insert(make_pair(it1->first, dist));
                    }
                }
            }
            
        } 
    } else {
        map<string, map<string, double>>::iterator it3 = tablee.begin();
        map<string, Especie>::iterator it1 = mesp.begin();
        map<string,Especie>::iterator it = mesp.find(id);
        while (it1 != it) {
            it3->second.erase(id);
            ++it1;
            ++it3;
        }

    }
}

double Cjt_Especies::species_distance(string id1, string id2){
    if (id1 == id2) return 0;
    it = mesp.find(id1);
    Especie a = it->second;
    it = mesp.find(id2);
    Especie b = it->second;
    map<string,int> k1;
    map<string,int> k2;
    map<string,int>::const_iterator it1;
    map<string,int>::const_iterator it2;
    k1 = a.query_kmer();
    k2 = b.query_kmer();
    it1 = k1.begin(), it2 = k2.begin();
    double ig = 0, total = 0;
    while (it1 != k1.end() and it2 != k2.end()) {
        if (it1->first < it2->first) {
            total += it1->second;
            ++it1;
        }
        else if (it2->first < it1->first) {
            total += it2->second;
            ++it2;
        }
        else {
            ig += min(it1->second, it2->second);
            total += it2->second;
            total += it1->second;
            ++it1;
            ++it2;
        }
    }
    while (it1 != k1.end()) {
        total += it1->second;
        ++it1;
    }
    while (it2 != k2.end()) {
        total += it2->second;
        ++it2; 
    }
    return (1 - (ig / (total-ig))) * 100;
}

map<string, Especie> Cjt_Especies::query_mesp() const {
    return mesp;
}

bool Cjt_Especies::species_exist(string id) {
    it = mesp.find(id);
    if (it != mesp.end()) {
        return true;
    }
    else return false;
}

Especie Cjt_Especies::find_species(string id) {
    it = mesp.find(id);
    return it->second;
}

void Cjt_Especies::read_species(int n, int k) {
    mesp.erase(mesp.begin(), mesp.end());
    tablee.erase(tablee.begin(), tablee.end());
    Especie aux;
    int i = 0; 
    while (i < n) {
        aux.read_single_species(k);
        string id = aux.query_identifier();
        mesp.insert(make_pair(id, aux));
        ++i;
    }
    initialize_distances();
  
}

void Cjt_Especies::print_species() {
    it = mesp.begin();
    while(it != mesp.end()) {
        cout << it->first << " " << it->second.query_gene() << endl;
        ++it;
    }
}



void Cjt_Especies::print_table_species() {
    if (mesp.size() != 0) {
        int i = 0;
        for(tablee_columne_iterator it1 = tablee.begin(); it1 != tablee.end(); ++it1) {
            cout << it1->first << ":";
            if(i < mesp.size()-1) cout << " ";
            tablee_rowe_iterator it2 = it1->second.begin();
            int j = 0;
            while(it2 != it1->second.end()) {
                cout << it2->first << " (" << it2->second << ")";
                if(j < it1->second.size()-1) cout << " ";
                ++it2;
                ++j;
            }
            ++i;
            cout << endl;
        }
    }
}

map<string, map<string, double> > Cjt_Especies::query_tablee() const{
    return tablee;
}

