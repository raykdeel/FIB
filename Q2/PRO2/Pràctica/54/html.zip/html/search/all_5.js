var searchData=
[
  ['find_5fcluster',['find_cluster',['../class_cjt___clusters.html#a4ab91d8e8222f35b4c9592c5ab2b4bf3',1,'Cjt_Clusters']]],
  ['find_5fspecies',['find_species',['../class_cjt___especies.html#a1e01bf8dfbde0983404efba05bd1b4b3',1,'Cjt_Especies']]]
];
