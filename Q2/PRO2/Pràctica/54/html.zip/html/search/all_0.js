var searchData=
[
  ['add_5fcluster',['add_cluster',['../class_cjt___clusters.html#ace64164c455de6b3e91b774ad95d93ac',1,'Cjt_Clusters']]],
  ['add_5fspecies',['add_species',['../class_cjt___especies.html#ab0aafd7fe0f24410a24aec9ff934bce0',1,'Cjt_Especies']]]
];
