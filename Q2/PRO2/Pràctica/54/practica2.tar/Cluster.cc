#include <iostream>
#include "Cluster.hh"
#include <string>
using namespace std;

//CONSTRUCTORES

Cluster::Cluster() {
}

Cluster::Cluster(BinTree<string> aux) {
    tree = aux;
}

//MODIFICADORES

void Cluster::clusters_fusion(const Cluster& A, const Cluster& B, const string& a) {
    BinTree<string> d = A.query_tree();
    BinTree<string> e = B.query_tree();
    tree = BinTree<string> (a, d, e);
}

//CONSULTORES

BinTree<string> Cluster::query_tree() const{
    return tree;
}

int Cluster::cluster_size() const{
    if (tree.empty()) return 0;
    else {
        Cluster aux1(tree.left()), aux2(tree.right());

        return 1 + aux1.cluster_size() + aux2.cluster_size();
    }
}

