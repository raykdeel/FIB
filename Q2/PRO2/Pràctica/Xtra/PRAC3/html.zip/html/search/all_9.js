var searchData=
[
  ['quitar_5fitems',['quitar_items',['../class_cjt__salas.html#acd5d8368e51d7bbd557958063c81cc43',1,'Cjt_salas']]],
  ['quitar_5fitems_5fsala',['quitar_items_sala',['../class_sala.html#af099ecd547afeb3a34fc75639372f330',1,'Sala']]],
  ['quitar_5fprod',['quitar_prod',['../class_cjt__productos.html#a2da6626c288772c1169dcf32c39202e6',1,'Cjt_productos']]]
];
