var searchData=
[
  ['almacen',['Almacen',['../class_almacen.html#a68a6084d5775d391c52d4825072a0612',1,'Almacen::Almacen()'],['../class_almacen.html#a1f4b6a1196d0c571c06012096e9401a2',1,'Almacen::Almacen(BinTree&lt; int &gt; aux)']]]
];
