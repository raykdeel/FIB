var searchData=
[
  ['redimensionar',['redimensionar',['../class_cjt__salas.html#af4a9c609def322edba117ae76aa0b3b9',1,'Cjt_salas']]],
  ['reorganizar',['reorganizar',['../class_cjt__salas.html#a540d49e9ee9a7a078e18f610399335b6',1,'Cjt_salas::reorganizar()'],['../class_sala.html#aaac8d848595b493ea08516f2101b829e',1,'Sala::reorganizar()']]]
];
