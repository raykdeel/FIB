var searchData=
[
  ['columnas',['columnas',['../class_sala.html#af3c278931f26e28e77fa363e9be82000',1,'Sala']]]
];
