var searchData=
[
  ['sala_2ecc',['Sala.cc',['../_sala_8cc.html',1,'']]],
  ['sala_2ehh',['Sala.hh',['../_sala_8hh.html',1,'']]]
];
