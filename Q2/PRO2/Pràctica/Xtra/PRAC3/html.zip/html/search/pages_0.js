var searchData=
[
  ['ejemplo_20de_20diseño_20modular_3a_20_20gestión_20de_20un_20almacen_2e',['Ejemplo de diseño modular:  Gestión de un almacen.',['../index.html',1,'']]]
];
