var searchData=
[
  ['coleccion_2ehh',['coleccion.hh',['../coleccion_8hh.html',1,'']]],
  ['consultabool_5fio_2ehh',['ConsultaBool_IO.hh',['../_consulta_bool___i_o_8hh.html',1,'']]]
];
