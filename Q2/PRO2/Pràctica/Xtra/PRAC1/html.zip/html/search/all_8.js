var searchData=
[
  ['not',['NOT',['../class_consulta_bool.html#abbf85658b7a73337ff1b9324dc7ef92f',1,'ConsultaBool']]],
  ['nr_5ffotos',['nr_fotos',['../classcoleccion.html#ac291b795feb35acf9b76d8e49a1bca2e',1,'coleccion']]],
  ['nrfotos',['nrfotos',['../classalbum.html#a4e9af3981b2e7e014fd32fcc98a94211',1,'album']]]
];
