var searchData=
[
  ['tkaux',['tkaux',['../coleccion_8hh.html#a32872ef5d42cc0a875f542d7d272198d',1,'coleccion.hh']]]
];
