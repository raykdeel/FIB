var searchData=
[
  ['imprimir_5fnr_5falbums',['imprimir_nr_albums',['../classcoleccion.html#a7a5b61fd34603d1a8cb89c34c28405ea',1,'coleccion']]],
  ['imprimir_5fnr_5ffotos',['imprimir_nr_fotos',['../classalbum.html#a5726e282899c49346cb1fa106e8ad2f6',1,'album']]]
];
