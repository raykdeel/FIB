var searchData=
[
  ['especifiacio_20de_20la_20parctica_20de_20pro_20de_20sergio_20sadornil',['Especifiacio de la parctica de pro de Sergio Sadornil',['../index.html',1,'']]]
];
