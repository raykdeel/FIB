var searchData=
[
  ['fecha',['fecha',['../classfecha.html#a6775ef84b5838e12e28fd341793f4539',1,'fecha']]],
  ['foto',['foto',['../classfoto.html#a4e9b16f163de710b74a5cda3b11aa4a6',1,'foto']]]
];
