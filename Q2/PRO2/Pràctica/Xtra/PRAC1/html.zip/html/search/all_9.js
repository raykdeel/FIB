var searchData=
[
  ['obten_5falbum',['obten_album',['../classcoleccion.html#a94ad3518462534e969f7ed0c1dc81a6d',1,'coleccion']]],
  ['obten_5ffoto',['obten_foto',['../classalbum.html#ad5d72a600eb08ebdb161b023c038a38e',1,'album::obten_foto()'],['../classcoleccion.html#adf3dbb1f4ebf2beb09bb44c754f4b341',1,'coleccion::obten_foto()']]],
  ['or',['OR',['../class_consulta_bool.html#ac0fd367af190b8440c9d2a9bbd2a994a',1,'ConsultaBool']]]
];
