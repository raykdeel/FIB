var searchData=
[
  ['agrega_5falbum',['agrega_album',['../classcoleccion.html#a3b91c86e1a75c993802e71e94e20ac89',1,'coleccion']]],
  ['agrega_5ffoto',['agrega_foto',['../classalbum.html#a97ae45c9e37c2995136f80e7810668a3',1,'album']]],
  ['album',['album',['../classalbum.html#a43a2caad74379d0c93af067078fbad57',1,'album']]],
  ['albumes_5ffoto',['albumes_foto',['../classcoleccion.html#a5d2eef177e6b8871f04afb4451179af0',1,'coleccion']]],
  ['and',['AND',['../class_consulta_bool.html#a88f071e4554cc471f1cc22de6bd2d394',1,'ConsultaBool']]]
];
