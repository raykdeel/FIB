var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5falbum',['modificar_album',['../classcoleccion.html#a9b7daa7ac8e7f151f9ddedce37e92d51',1,'coleccion']]],
  ['modificar_5fall',['modificar_all',['../classcoleccion.html#a10bfcd8a80fa642acbeda1c2ed8d4c31',1,'coleccion']]],
  ['modificar_5ffoto',['modificar_foto',['../classalbum.html#ad97559d3200e67c1cdbf07efe6f940f1',1,'album']]],
  ['modificar_5ffoto_5fcol',['modificar_foto_col',['../classcoleccion.html#afe8cddfb38c0986d6b7633e63f535d8c',1,'coleccion']]]
];
