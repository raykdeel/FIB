var searchData=
[
  ['coleccion',['coleccion',['../classcoleccion.html',1,'']]],
  ['consultabool',['ConsultaBool',['../class_consulta_bool.html',1,'']]]
];
