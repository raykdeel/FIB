var searchData=
[
  ['afegir_5fcluster',['afegir_cluster',['../class_cjt___clusters.html#a0f77012c09e43a3be17043ddf4ac061c',1,'Cjt_Clusters']]],
  ['afegir_5fespecie',['afegir_Especie',['../class_cjt___especies.html#a4ac8e8ed749e7e33b0c84da57226081c',1,'Cjt_Especies']]]
];
