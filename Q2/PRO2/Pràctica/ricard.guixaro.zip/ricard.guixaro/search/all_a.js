var searchData=
[
  ['taula_5fdistancies',['taula_distancies',['../class_cjt___especies.html#ad7b8b31101e1c5e652bc39cdd3423608',1,'Cjt_Especies']]]
];
