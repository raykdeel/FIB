var searchData=
[
  ['wpgma',['WPGMA',['../class_cjt___clusters.html#a8c78c10962ac2061982f4b2a0d69d3f4',1,'Cjt_Clusters']]]
];
