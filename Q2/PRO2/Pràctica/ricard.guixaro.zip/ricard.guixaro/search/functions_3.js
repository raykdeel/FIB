var searchData=
[
  ['eliminar_5fcluster',['eliminar_cluster',['../class_cjt___clusters.html#ae29d4a65bc134e2b23a41802f079ec96',1,'Cjt_Clusters']]],
  ['eliminar_5fespecie',['eliminar_Especie',['../class_cjt___especies.html#af1259ace6df2a61d5c443a906a2f0a44',1,'Cjt_Especies']]],
  ['escriu',['escriu',['../class_especie.html#ae0db47c73d1ea93aebdae93b77ec468e',1,'Especie']]],
  ['escriu_5farbre',['escriu_arbre',['../class_cjt___clusters.html#a8a0b0b5985ebe229db5a7d21a5766146',1,'Cjt_Clusters']]],
  ['escriu_5fcjt_5fclusters',['escriu_cjt_clusters',['../class_cjt___clusters.html#a82915f95df07a445025dbe7dad354088',1,'Cjt_Clusters']]],
  ['escriu_5fcjt_5fespecies',['escriu_cjt_especies',['../class_cjt___especies.html#ab6945c71800e38fae624c94eae709f2c',1,'Cjt_Especies']]],
  ['escriu_5fcluster',['escriu_cluster',['../class_cluster.html#a965f3fd78351c4eb06864f4811993823',1,'Cluster']]],
  ['escriu_5ftaulac',['escriu_taulac',['../class_cjt___clusters.html#acf3f5238917b3b9aa0594ac3425d42a2',1,'Cjt_Clusters']]],
  ['especie',['Especie',['../class_especie.html#a272c2488719cc9874b2f174906675b3d',1,'Especie::Especie()'],['../class_especie.html#aa3b5fc51a5bef65a01fd84ba7e17b4fb',1,'Especie::Especie(string id, string g)']]],
  ['existeix_5fcluster',['existeix_Cluster',['../class_cjt___clusters.html#a207e8c9067775231a452b7038c864b6a',1,'Cjt_Clusters']]],
  ['existeix_5fespecie',['existeix_Especie',['../class_cjt___especies.html#acd5a61de448f77d0356e0ba8d642b2e0',1,'Cjt_Especies']]]
];
