var searchData=
[
  ['imprimir_5fcluster',['imprimir_cluster',['../class_cjt___clusters.html#a0540284cbc0495cff9ff214a6b4f77a2',1,'Cjt_Clusters']]],
  ['inicialitzar_5fclusters',['inicialitzar_clusters',['../class_cjt___clusters.html#a02c91a6f1651749af64a72909eb725dc',1,'Cjt_Clusters']]]
];
