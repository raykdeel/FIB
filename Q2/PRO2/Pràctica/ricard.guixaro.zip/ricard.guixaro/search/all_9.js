var searchData=
[
  ['pràctica_20_28primavera_202020_29_2e',['Pràctica (Primavera 2020).',['../index.html',1,'']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
