var searchData=
[
  ['llegir',['llegir',['../class_cjt___especies.html#ac24295a03ed6d15e58071b22778ec102',1,'Cjt_Especies::llegir()'],['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie::llegir()']]]
];
