var searchData=
[
  ['dist_5fmin',['dist_min',['../class_cjt___clusters.html#a6cf197c0aa4bf1630c24fc0414f07378',1,'Cjt_Clusters']]],
  ['distancia_5fcluster',['distancia_cluster',['../class_cjt___clusters.html#a94f19cb7786aec229365c7dc6f72ce70',1,'Cjt_Clusters']]]
];
