var searchData=
[
  ['table_5fclusters',['table_clusters',['../class_cjt___clusters.html#a6af3fcf70683cdb88f137f6f51002939',1,'Cjt_Clusters']]],
  ['table_5fspecies',['table_species',['../class_cjt___especies.html#ae56d242080836b8d3db505f0a8623090',1,'Cjt_Especies']]],
  ['tree',['tree',['../class_cluster.html#a3bfc63bfed216dd410ec687fe533c34c',1,'Cluster']]]
];
