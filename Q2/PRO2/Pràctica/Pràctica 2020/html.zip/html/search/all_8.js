var searchData=
[
  ['kmer',['kmer',['../class_especie.html#aa438e3e2f785d96c0ac51e83f60a5879',1,'Especie']]]
];
