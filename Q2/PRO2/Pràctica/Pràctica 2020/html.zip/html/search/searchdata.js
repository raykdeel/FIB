var indexSectionsWithContent =
{
  0: "abcdefgiklmnpqrstvwx",
  1: "bcen",
  2: "bcep",
  3: "abcdefilmnpqrsvw",
  4: "giklmprtx",
  5: "mt",
  6: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Definicions de Tipus",
  6: "Pàgines"
};

