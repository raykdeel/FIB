var searchData=
[
  ['initialize_5fclusters',['initialize_clusters',['../class_cjt___clusters.html#a35d2c4c28bee51017f4ac9049a0fe6e9',1,'Cjt_Clusters']]],
  ['initialize_5fdistances',['initialize_distances',['../class_cjt___especies.html#ab041e83795b06d02ba7bad8422189361',1,'Cjt_Especies']]]
];
