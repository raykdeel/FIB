var searchData=
[
  ['find_5fprint_5fcluster',['find_print_cluster',['../class_cjt___clusters.html#a0072a1e21a58e0ab64ac96ccff068229',1,'Cjt_Clusters']]],
  ['find_5fspecies',['find_species',['../class_cjt___especies.html#a1e01bf8dfbde0983404efba05bd1b4b3',1,'Cjt_Especies']]]
];
