var searchData=
[
  ['gene',['gene',['../class_especie.html#affa45d2f858415333f43caf121c7663a',1,'Especie']]]
];
